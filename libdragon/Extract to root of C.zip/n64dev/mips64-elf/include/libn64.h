#ifndef _LIBN64_H
#define _LIBN64_H

#include <N64sys.h>
#include <VI.h>
#include <SI.h>
#include <AI.h>
#include <MI.h>

#endif
